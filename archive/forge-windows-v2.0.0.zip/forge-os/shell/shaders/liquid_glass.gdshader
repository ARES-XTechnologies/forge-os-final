// FORGE OS — Liquid Glass with Contour Glow
// True refractive glass: no blur, no frost. The panel is modelled as a thick convex slab
// with a rounded bevel. Light passing through the bevel is bent (refraction), split into
// colours (dispersion) and catches a specular rim. The flat interior slightly magnifies
// what's behind it, exactly like a real glass lens.
//
// Contour glow: a living line of light that follows the edge. It takes its colour from
// whatever is behind the glass (or a chosen colour), carries a soft highlight that slowly
// orbits the panel, blooms just outside the edge and brightens when focused.
//
// The ColorRect is larger than the panel by `margin` so shadow, halo and glow render
// in the same pass.
shader_type canvas_item;
render_mode unshaded;

uniform sampler2D screen_tex : hint_screen_texture, filter_linear_mipmap, repeat_disable;

uniform vec2 size = vec2(400.0, 200.0);   // full rect size in px (incl. margin)
uniform float margin = 40.0;              // px reserved around the panel for shadow/glow
uniform float radius = 28.0;
uniform float bevel = 22.0;               // width of the curved edge in px
uniform float refraction = 1.0;           // global strength (settings)
uniform float edge_bend = 26.0;           // px of displacement at the very edge
uniform float magnify = 0.035;            // interior lens magnification
uniform float dispersion = 1.0;
uniform vec4 tint : source_color = vec4(0.62, 0.72, 1.0, 1.0);
uniform float tint_amount = 0.10;
uniform float body_dim = 0.0;             // darkens what is seen through big sheets for legibility
uniform bool layered = false;             // glass on glass: translucent layer, no re-sampling
uniform float smoke = 0.0;                // layered only: dark smoked body for glass drawn over a running game
uniform float brightness = 0.035;
uniform float glass_brightness = 1.0;     // user setting: 0 = darker, 1 = default, 2 = very bright
uniform float specular = 1.0;
uniform float shadow = 0.55;
uniform float focus = 0.0;                // 0..1 focus glow
uniform vec4 focus_color : source_color = vec4(0.49, 0.78, 1.0, 1.0);
uniform float press = 0.0;
uniform float opacity = 1.0;
uniform float shine = -1.0;               // travelling highlight / focus sweep, -1 = off

// Contour glow
uniform bool glow_on = true;
uniform float glow_strength = 1.0;
uniform int glow_mode = 0;                // 0 adaptive, 1 accent, 2 gold, 3 ice, 4 rainbow
uniform bool glow_motion = true;
uniform float glow_seed = 0.0;            // per-panel phase so lights don't move in lockstep

float sd_round_box(vec2 p, vec2 b, float r) {
	vec2 q = abs(p) - b + vec2(r);
	return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
}

vec3 hue(float h) {
	return clamp(abs(fract(h + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
}

// Colour of the contour light at this spot.
vec3 glow_colour(vec2 suv, vec2 n, vec2 spx, float ang) {
	if (glow_mode == 1 || (glow_mode == 0 && smoke > 0.0)) return mix(focus_color.rgb, vec3(1.0), 0.25);
	if (glow_mode == 2) return vec3(1.0, 0.80, 0.46);
	if (glow_mode == 3) return vec3(0.70, 0.90, 1.0);
	if (glow_mode == 4) return mix(hue(ang / 6.2831 + TIME * 0.05 + glow_seed), vec3(1.0), 0.3);
	// Adaptive: average colour of the scene just outside this edge, saturated into light.
	vec3 bg = textureLod(screen_tex, suv + n * spx * 40.0, 4.5).rgb;
	float mx = max(max(bg.r, bg.g), max(bg.b, 0.04));
	vec3 c = bg / mx;
	float l = dot(c, vec3(0.299, 0.587, 0.114));
	c = mix(vec3(l), c, 1.35);                  // a touch more saturation
	return clamp(mix(c, vec3(1.0), 0.32), 0.0, 1.0);
}

// 0..1 brightness of the travelling highlights at this angle.
float orbit(float ang) {
	float t = glow_motion ? TIME * 0.42 + glow_seed * 6.2831 : glow_seed * 6.2831 + 2.2;
	float a = pow(max(cos(ang - t), 0.0), 7.0);
	float b = pow(max(cos(ang - t + 3.14159), 0.0), 14.0) * 0.45;
	float sweep = 0.0;
	if (shine > -0.5) {
		// focus sweep: one bright spark runs once around the edge
		float s = shine * 6.2831 - 1.5708;
		sweep = pow(max(cos(ang - s), 0.0), 18.0) * (1.0 - smoothstep(0.85, 1.2, shine)) * 1.6;
	}
	return a + b + sweep;
}

void fragment() {
	vec2 px = UV * size;
	vec2 half_panel = size * 0.5 - vec2(margin);
	vec2 c = size * 0.5;
	vec2 p = px - c;
	float r = min(radius, min(half_panel.x, half_panel.y));
	float d = sd_round_box(p, half_panel, r);
	vec2 spx = SCREEN_PIXEL_SIZE;
	float ang = atan(p.y / max(half_panel.y, 1.0), p.x / max(half_panel.x, 1.0));
	float gb = clamp(glass_brightness, 0.0, 2.0);

	// Surface normal from the SDF gradient (outward-pointing).
	vec2 e = vec2(1.0, 0.0);
	vec2 n = normalize(vec2(
		sd_round_box(p + e.xy, half_panel, r) - sd_round_box(p - e.xy, half_panel, r),
		sd_round_box(p + e.yx, half_panel, r) - sd_round_box(p - e.yx, half_panel, r)) + 1e-5);

	float gl = glow_on ? glow_strength : 0.0;
	vec3 gcol = vec3(0.0);
	float gorb = 0.0;
	if (gl > 0.0) {
		gcol = glow_colour(SCREEN_UV, n, spx, ang);
		gorb = orbit(ang);
	}
	// Base level everywhere on the edge + travelling highlights + focus lift.
	float glevel = gl * (0.32 + 0.95 * gorb) * (0.75 + 0.9 * focus);

	// --- outside the panel: shadow + focus halo + contour bloom --------------------
	if (d > 0.0) {
		float sd = sd_round_box(p - vec2(0.0, 10.0 + 6.0 * focus), half_panel, r);
		float sh = exp(-max(sd, 0.0) / (14.0 + 10.0 * focus)) * shadow * 0.55;
		float halo = exp(-d / 10.0) * focus * 0.55 + exp(-d / 30.0) * focus * 0.18;
		float bloom = (exp(-d / 3.5) * 0.55 + exp(-d / 14.0) * 0.22) * glevel;
		float edge_fade = 1.0 - smoothstep(margin * 0.55, margin * 0.98, d + 10.0);
		sh *= edge_fade;
		halo *= edge_fade;
		bloom *= edge_fade;
		float a = clamp(sh + halo + bloom, 0.0, 1.0);
		vec3 col = (focus_color.rgb * halo + gcol * bloom * 1.3) / max(a, 0.001);
		COLOR = vec4(col, a * opacity);
	} else {
	// --- inside the panel ----------------------------------------------------------
	float bev = min(bevel, min(half_panel.x, half_panel.y));
	float h = clamp(-d / bev, 0.0, 1.0);          // 0 at the rim, 1 on the flat top
	float z = sqrt(1.0 - (1.0 - h) * (1.0 - h));   // convex profile
	float slope = 1.0 - z;                          // steep at the rim

	// Displacement in pixels: rim bends outward, interior magnifies toward the centre.
	vec2 disp = n * slope * slope * edge_bend * refraction * (1.0 + 0.6 * press);
	disp -= p * magnify * refraction;
	float k = 0.12 * dispersion * refraction;
	vec3 col = vec3(0.0);
	if (!layered) {
		col.r = texture(screen_tex, SCREEN_UV + disp * spx * (1.0 - k)).r;
		col.g = texture(screen_tex, SCREEN_UV + disp * spx).g;
		col.b = texture(screen_tex, SCREEN_UV + disp * spx * (1.0 + k)).b;
	}

	// Glass body: faint tint, a touch of brightness and a gentle top-to-bottom sheen.
	float vert = UV.y;
	col *= 1.0 - body_dim * 0.97 * smoothstep(0.0, 0.35, h);
	col = mix(col, tint.rgb, tint_amount * (0.8 + 0.4 * gb));
	col = col * (0.88 + 0.26 * gb) + (brightness + 0.035 * (1.0 - vert)) * (0.6 + 0.8 * gb) + press * 0.05;

	// Specular rim: key light from top-left, fill from bottom-right.
	vec2 L = normalize(vec2(-0.55, -1.0));
	float rim = pow(slope, 2.2);
	float key = max(dot(n, L), 0.0);
	float fill = max(dot(n, -L), 0.0);
	col += vec3(1.0) * rim * (0.55 * key + 0.16 * fill) * specular * (0.8 + 0.3 * gb);
	// Hairline edge that defines the silhouette.
	float hair = smoothstep(-1.6, -0.2, d) * (1.0 - smoothstep(-0.2, 0.0, d));
	col += vec3(1.0) * hair * (0.22 + 0.25 * key) * specular;
	// Inner caustic: a soft bright band just inside the bottom rim.
	float caustic = smoothstep(0.55, 1.0, UV.y) * pow(1.0 - h, 6.0) * 0.18;
	col += mix(vec3(1.0), focus_color.rgb, 0.5) * caustic;

	// Contour glow: crisp line on the rim + soft light spilling inward.
	if (gl > 0.0) {
		float line = smoothstep(-3.2, -0.9, d) * (1.0 - smoothstep(-0.7, 0.0, d));
		float spill = exp(d / 9.0) * 0.35 + exp(d / 26.0) * 0.10;
		col += gcol * (line * 1.25 + spill) * glevel;
	}

	// Focus: coloured rim + slightly brighter body.
	col += focus_color.rgb * focus * (pow(slope, 1.6) * 0.65 + 0.045);

	// Travelling diagonal shine (used when a card gains focus).
	if (shine > -0.5) {
		float diag = (UV.x + UV.y * 0.6) - shine * 2.2 + 0.3;
		float band = exp(-diag * diag * 90.0) * 0.22;
		col += vec3(band);
	}

	float aa = clamp(0.5 - d, 0.0, 1.0);
	if (layered) {
		float body = (0.10 + tint_amount * 0.8 + focus * 0.12) * (0.8 + 0.4 * gb);
		vec3 lc = col + tint.rgb * 0.25;
		float la = clamp(body + length(col) * 0.6, 0.0, 1.0);
		if (smoke > 0.0) {
			// Over a game: deep smoked glass so text stays readable on any scene.
			lc = mix(lc, vec3(0.04, 0.045, 0.085) + col * 0.9, smoke * 0.7);
			la = max(la, smoke);
		}
		COLOR = vec4(lc, aa * opacity * la);
	} else {
		COLOR = vec4(col, aa * opacity);
	}
	}
}
