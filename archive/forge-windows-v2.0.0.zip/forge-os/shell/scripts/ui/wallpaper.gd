class_name Wallpaper
extends ColorRect
## Animated liquid-light wallpaper. Parallax follows UI focus on a soft spring,
## so the whole world gently shifts as you move through games.

const SHADER := preload("res://shaders/wallpaper.gdshader")

var _mat: ShaderMaterial
var _t := 0.0
var parallax: Spring2
var dim: Spring
var reveal: Spring
var _palette_mix := 1.0
var _tint := Color.WHITE
var _tint_target := Color.WHITE
var _tint_amt: Spring
var _from: Array = []
var _to: Array = []

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_mat = ShaderMaterial.new()
	_mat.shader = SHADER
	material = _mat
	parallax = Spring2.preset(Vector2.ZERO, &"glide")
	dim = Spring.preset(0.0, &"smooth")
	reveal = Spring.preset(1.0, &"glide")
	_tint_amt = Spring.preset(0.0, &"glide")
	_t = randf() * 200.0
	_to = Tokens.palette()
	_from = _to
	_apply_palette(1.0)
	Config.changed.connect(func(k):
		if k == "appearance.palette":
			_from = _current_palette()
			_to = Tokens.palette()
			_palette_mix = 0.0)

func _current_palette() -> Array:
	var out := []
	for i in 5:
		out.append((_from[i] as Color).lerp(_to[i], _palette_mix))
	return out

func _apply_palette(k: float) -> void:
	var names := ["c_base", "c_a", "c_b", "c_c", "c_glow"]
	for i in 5:
		_mat.set_shader_parameter(names[i], (_from[i] as Color).lerp(_to[i], smoothstep(0.0, 1.0, k)))

## Dynamic theme: drift the sky's colours toward the focused game's art.
func set_game_color(c, on := true) -> void:
	if c == null or not on or not Config.get_b("appearance.dynamic"):
		_tint_amt.target = 0.0
		return
	_tint_target = c
	_tint_amt.target = 1.0

## Nudge the parallax target, e.g. from the focused card's screen position (-1..1).
func look_at_point(n: Vector2) -> void:
	if Config.get_b("appearance.parallax") and not Config.get_b("motion.reduce"):
		parallax.target = Vector2(n.x * 0.035, n.y * 0.02)

func _process(dt: float) -> void:
	if Config.get_b("appearance.wallpaper_animated"):
		_t += dt * Config.get_f("appearance.wallpaper_speed")
	if _palette_mix < 1.0:
		_palette_mix = minf(1.0, _palette_mix + dt * 0.8)
		_apply_palette(_palette_mix)
	var pv := parallax.step(dt)
	_mat.set_shader_parameter("t", _t)
	_mat.set_shader_parameter("parallax", pv)
	_mat.set_shader_parameter("res", size)
	_mat.set_shader_parameter("dim", dim.step(dt))
	_mat.set_shader_parameter("reveal", clampf(reveal.step(dt), 0.0, 1.0))
	_mat.set_shader_parameter("intensity", Config.get_f("appearance.wallpaper_intensity"))
	_tint = _tint.lerp(_tint_target, clampf(dt * 2.2, 0.0, 1.0))
	_mat.set_shader_parameter("game_tint", _tint)
	_mat.set_shader_parameter("game_tint_amount", clampf(_tint_amt.step(dt), 0.0, 1.0))
