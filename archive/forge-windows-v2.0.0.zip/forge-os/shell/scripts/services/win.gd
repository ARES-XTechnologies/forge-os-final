extends Node
## FORGE for Windows: everything that works differently from the Linux console.
##
## FORGE runs as a normal app under your own Windows account (same saves, mods, trainers
## and Steam as the desktop). Console mode hides the desktop and pauses what a console
## doesn't need; it's done by the "FORGE Console" scheduled task, which has admin rights
## (registered once by the installer, so there is never a UAC prompt). A watchdog brings
## the desktop back if FORGE ever closes unexpectedly.

signal console_changed(on: bool)

const TASK := "FORGE Console"

var active := OS.get_name() == "Windows"
var dir := ""                  # install folder: FORGE.exe, forge-helper.exe, forge-console.ps1
var helper := ""
var data := ""                 # %LOCALAPPDATA%\FORGE
var in_console := false
var _vol_busy := false
var _vol_next := -1.0
var _wait_t := 0.0
var _wait_tries := 0

func _ready() -> void:
	if not active:
		set_process(false)
		return
	dir = OS.get_executable_path().get_base_dir().replace("\\", "/")
	helper = dir.path_join("forge-helper.exe")
	data = OS.get_environment("LOCALAPPDATA").replace("\\", "/").path_join("FORGE")
	DirAccess.make_dir_recursive_absolute(data)
	write_prefs()
	Config.changed.connect(_on_config)
	# Borderless full screen: games, Windows Settings and UAC prompts can show on top,
	# and Alt+Tab still works.
	get_window().mode = Window.MODE_FULLSCREEN
	if has_helper():
		OS.create_process(helper, PackedStringArray(["watchdog", str(OS.get_process_id())]))
	set_process(false)
	# Always ask on start: the task checks for itself whether console mode is really on
	# (a leftover marker after a power cut must not fool FORGE).
	in_console = false
	if Config.get_b("win.console_mode") and not OS.get_cmdline_user_args().has("--no-console"):
		enter_console()

func has_helper() -> bool:
	return FileAccess.file_exists(helper)

## Runs forge-helper.exe on a worker thread. cb(text, code)
func h(args: Array, cb := Callable()) -> void:
	if not has_helper():
		if cb.is_valid():
			cb.call("", 1)
		return
	Sys.run(helper, args, cb)

## Same, but waits for the answer (only for quick look-ups at start-up).
func h_now(args: Array) -> String:
	if not has_helper():
		return ""
	var out := []
	OS.execute(helper, PackedStringArray(args), out)
	return str(out[0]).strip_edges() if not out.is_empty() else ""

func _on_config(k: String) -> void:
	match k:
		"win.boost":
			write_prefs()
		"win.autostart":
			set_autostart(Config.get_b("win.autostart"))
		"win.console_mode":
			if Config.get_b("win.console_mode"):
				enter_console()

func write_prefs() -> void:
	var f := FileAccess.open(data.path_join("console-prefs.json"), FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify({"boost": Config.get_b("win.boost")}))

# ------------------------------------------------------------------ console mode
func enter_console() -> void:
	if in_console:
		return
	# Clear an old marker so the check below only sees the task's fresh answer.
	DirAccess.remove_absolute(data.path_join("console-active"))
	_request("enter")
	_wait_tries = 0
	_wait_t = 0.0
	set_process(true)

## Checks every half second whether the admin task finished entering console mode.
func _process(dt: float) -> void:
	_wait_t += dt
	if _wait_t < 0.5:
		return
	_wait_t = 0.0
	_wait_tries += 1
	if FileAccess.file_exists(data.path_join("console-active")):
		in_console = true
		set_process(false)
		console_changed.emit(true)
		# Explorer just closed: make sure FORGE is the window in front.
		bring_to_front()
		return
	if _wait_tries == 12:
		_request("enter")            # the task was busy (e.g. sign-in check); ask once more
	elif _wait_tries > 30:
		set_process(false)
		Shellbus.notify({"title": "Console mode isn't set up", "body": "Reinstall FORGE with FORGE-Setup.exe to hide the desktop.", "icon": "info", "color": Tokens.WARN})

func _request(what: String) -> void:
	var f := FileAccess.open(data.path_join("console-request.txt"), FileAccess.WRITE)
	if f == null:
		return
	f.store_string(what)
	f.close()
	Sys.run("schtasks", ["/run", "/tn", TASK])

## Leave console mode and go to the Windows desktop. FORGE closes afterwards.
func go_to_desktop() -> void:
	Config.save_now()
	Shellbus.notify({"title": "Going to the desktop", "body": "Everything goes back to how it was.", "icon": "display"})
	if not has_helper():
		OS.create_process("explorer.exe", PackedStringArray())
		get_tree().quit(0)
		return
	h(["desktop"], func(_t, _c): get_tree().quit(0))

## Start FORGE when you sign in to Windows (no UAC: it's a normal app).
func set_autostart(on: bool) -> void:
	var key := "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run"
	if on:
		var exe := OS.get_executable_path().replace("/", "\\")
		Sys.run("reg", ["add", key, "/v", "FORGE", "/t", "REG_SZ", "/d", "\"%s\"" % exe, "/f"])
	else:
		Sys.run("reg", ["delete", key, "/v", "FORGE", "/f"])

func bring_to_front() -> void:
	var w := get_window()
	if w.mode == Window.MODE_MINIMIZED:
		w.mode = Window.MODE_FULLSCREEN
	DisplayServer.window_move_to_foreground()
	w.grab_focus()
	h(["focus-pid", str(OS.get_process_id())])

# ------------------------------------------------------------------ power
func power(action: String) -> void:
	Config.save_now()
	match action:
		"suspend":
			h(["sleep"])
		"poweroff", "reboot":
			var flag := "/s" if action == "poweroff" else "/r"
			# Restore everything first so Windows starts normally next time.
			h(["desktop"], func(_t, _c):
				OS.create_process("shutdown", PackedStringArray([flag, "/t", "0"]))
				get_tree().quit(0))

func set_power_mode(mode: String) -> void:
	var guid := {"performance": "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c", "balanced": "381b4222-f694-41f0-9685-ff5bb260df2e", "power-saver": "a1841308-3541-4fab-bc81-f71556f20b4a"}
	if guid.has(mode):
		Sys.run("powercfg", ["/setactive", guid[mode]])

# ------------------------------------------------------------------ games
## The folder a game runs from (used to find, pause, focus and close its processes).
func game_folder(g: Dictionary) -> String:
	var src := str(g.get("source", "steam"))
	if src in ["local", "usb"]:
		return str(g.get("installdir", ""))
	if src == "steam" and str(g.get("library", "")) != "" and str(g.get("installdir", "")) != "":
		return str(g.library).path_join("steamapps/common").path_join(str(g.installdir))
	return ""

## Launch an .exe (or .bat/.lnk) from its own folder. cb(pid)
func launch(exe: String, args: Array, cb: Callable) -> void:
	h(["launch", exe] + args, func(t: String, c: int):
		cb.call(int(t) if c == 0 else 0))

func steam_root() -> String:
	return h_now(["steam-root"])

## cb(appid) — 0 when no Steam game is running.
func steam_running(cb: Callable) -> void:
	h(["steam-running"], func(t: String, _c): cb.call(int(t)))

# ------------------------------------------------------------------ audio
func audio_status(cb: Callable) -> void:
	h(["volume"], func(t: String, c: int):
		var p := t.split(" ", false)
		var vol := float(p[0]) if c == 0 and p.size() > 0 else 0.5
		var muted := p.size() > 1 and p[1] == "1"
		cb.call({"sinks": [], "volume": vol, "muted": muted}))

## Sliders send many values; only the newest one is applied, one at a time.
func set_volume(v: float) -> void:
	_vol_next = clampf(v, 0.0, 1.0)
	if not _vol_busy:
		_apply_volume()

func _apply_volume() -> void:
	if _vol_next < 0.0:
		_vol_busy = false
		return
	_vol_busy = true
	var v := _vol_next
	_vol_next = -1.0
	h(["volume-set", "%.3f" % v], func(_t, _c): _apply_volume())

# ------------------------------------------------------------------ network
func net_status(cb: Callable) -> void:
	h(["net"], func(t: String, _c):
		var st := {"wifi_on": false, "wired": false, "wifi_ssid": "", "ip": "", "online": false}
		for line in t.split("\n", false):
			var kv := line.strip_edges().split("=", true, 1)
			if kv.size() < 2:
				continue
			match kv[0]:
				"wired": st.wired = kv[1] == "1"
				"wifi": st.wifi_on = kv[1] == "1"
				"ssid": st.wifi_ssid = kv[1]
				"ip": st.ip = kv[1]
		st.online = st.ip != ""
		cb.call(st))

func wifi_scan(cb: Callable) -> void:
	h(["wifi-scan"], func(t: String, c: int):
		var list := []
		if c == 0:
			for line in t.split("\n", false):
				var p := line.strip_edges().split("|")
				if p.size() >= 4 and p[0] != "":
					list.append({"ssid": p[0], "signal": int(p[1]), "secure": p[2] == "1", "active": p[3] == "1"})
		list.sort_custom(func(a, b): return (a.active and not b.active) or (a.active == b.active and a.signal > b.signal))
		cb.call(list))

func wifi_connect(ssid: String, password: String, cb: Callable) -> void:
	var args := ["wifi-connect", ssid]
	if password != "":
		args.append(password)
	h(args, func(t: String, c: int): cb.call(c == 0, t))

## Windows' own settings pages (Bluetooth pairing, display, sound…), shown over FORGE.
func open_settings(page: String) -> void:
	OS.shell_open("ms-settings:" + page)

# ------------------------------------------------------------------ info
## cb([{mount, size, used, free}])
func storage(cb: Callable) -> void:
	h(["drives"], func(t: String, _c):
		var out := []
		for line in t.split("\n", false):
			var p := line.strip_edges().split("|")
			if p.size() >= 5:
				var label := p[3] if p[3] != "" else ("USB drive" if p[4] == "usb" else "Local disk")
				out.append({"mount": "%s  %s" % [p[0].trim_suffix("/"), label], "path": p[0], "size": int(p[2]), "free": int(p[1]), "used": int(p[2]) - int(p[1]), "usb": p[4] == "usb"})
		cb.call(out))

var _about := {}

func about() -> Dictionary:
	if _about.is_empty():
		for line in h_now(["about"]).split("\n", false):
			var kv := line.strip_edges().split("=", true, 1)
			if kv.size() == 2:
				_about[kv[0]] = kv[1]
	return _about

func screenshot(path: String, cb: Callable) -> void:
	h(["screenshot", path.replace("/", "\\")], func(_t, c: int): cb.call(c == 0))
