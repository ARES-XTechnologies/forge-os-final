// FORGE for Windows — native helper.
// Small command-line tool the console UI calls for things Godot can't do on its own.
// Built from this file by the GitHub workflow with the C# compiler that ships with
// every copy of Windows (csc.exe from .NET Framework 4), so no extra downloads.
//
//   forge-helper volume                  print "<0..1> <0|1 muted>"
//   forge-helper volume-set <0..1>
//   forge-helper mute <0|1>
//   forge-helper alive <folder>          print how many processes run from that folder
//   forge-helper boost <folder>          give those processes High priority
//   forge-helper suspend <folder>        pause the game (Pause while menu is open)
//   forge-helper resume <folder>
//   forge-helper quit <folder>           ask the game to close, force it after 8 s
//   forge-helper focus <folder>          bring the game window to the front
//   forge-helper focus-pid <pid>         bring a process window (FORGE itself) to the front
//   forge-helper steam-root              print Steam's install folder
//   forge-helper steam-running           print the running Steam game's app id (0 = none)
//   forge-helper screenshot <file.png>   capture the whole screen
//   forge-helper drives                  print "root|free|total|label|type" per drive
//   forge-helper about                   print os=, gpu=, ram= lines
//   forge-helper wifi-connect <ssid> [password]
//   forge-helper watchdog <forge-pid>    if FORGE crashes in console mode, bring the desktop back
//   forge-helper desktop                 leave console mode: restore settings, start Explorer
//   forge-helper launch <exe> [args...]  start a game from its own folder, print its pid
//   forge-helper net                     print wired=, wifi=, ssid=, ip= lines
//   forge-helper wifi-scan               print "ssid|signal|secure|active" per network
//   forge-helper sleep                   put the PC to sleep
//
// Exit code 0 = done, 1 = failed, 2 = bad arguments.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Management;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

static class ForgeHelper
{
    // ------------------------------------------------------------------ entry
    static int Main(string[] args)
    {
        if (args.Length == 0) return 2;
        try
        {
            string cmd = args[0].ToLowerInvariant();
            string a1 = args.Length > 1 ? args[1] : "";
            switch (cmd)
            {
                case "volume": return Volume.Print();
                case "volume-set": return Volume.Set(ParseFloat(a1));
                case "mute": return Volume.Mute(a1 == "1");
                case "alive": Console.WriteLine(ProcsIn(a1).Count); return 0;
                case "boost": return Boost(a1);
                case "suspend": return SuspendAll(a1, true);
                case "resume": return SuspendAll(a1, false);
                case "quit": return Quit(a1);
                case "focus": return FocusFolder(a1);
                case "focus-pid": return FocusPid(int.Parse(a1));
                case "steam-root": return SteamRoot();
                case "steam-running": return SteamRunning();
                case "screenshot": return Screenshot(a1);
                case "drives": return Drives();
                case "about": return About();
                case "wifi-connect": return WifiConnect(a1, args.Length > 2 ? args[2] : "");
                case "watchdog": return Watchdog(int.Parse(a1));
                case "desktop": return Desktop();
                case "launch": return Launch(args);
                case "net": return Net();
                case "wifi-scan": return WifiScan();
                case "sleep": Application.SetSuspendState(PowerState.Suspend, false, false); return 0;
            }
            return 2;
        }
        catch (Exception e)
        {
            Console.Error.WriteLine(e.Message);
            return 1;
        }
    }

    static float ParseFloat(string s)
    {
        return float.Parse(s, System.Globalization.CultureInfo.InvariantCulture);
    }

    // ------------------------------------------------------------------ native
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool CloseHandle(IntPtr h);
    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    static extern bool QueryFullProcessImageName(IntPtr h, int flags, StringBuilder name, ref int size);
    [DllImport("ntdll.dll")]
    static extern int NtSuspendProcess(IntPtr h);
    [DllImport("ntdll.dll")]
    static extern int NtResumeProcess(IntPtr h);
    [DllImport("user32.dll")]
    static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")]
    static extern bool BringWindowToTop(IntPtr h);
    [DllImport("user32.dll")]
    static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")]
    static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")]
    static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
    [DllImport("kernel32.dll")]
    static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")]
    static extern bool AttachThreadInput(uint a, uint b, bool attach);
    [DllImport("user32.dll")]
    static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);

    const uint QUERY_LIMITED = 0x1000;
    const uint SUSPEND_RESUME = 0x0800;

    static string PathOf(int pid)
    {
        IntPtr h = OpenProcess(QUERY_LIMITED, false, pid);
        if (h == IntPtr.Zero) return null;
        try
        {
            StringBuilder sb = new StringBuilder(1024);
            int size = sb.Capacity;
            return QueryFullProcessImageName(h, 0, sb, ref size) ? sb.ToString() : null;
        }
        finally { CloseHandle(h); }
    }

    static string NormDir(string dir)
    {
        string d = Path.GetFullPath(dir.Replace('/', '\\'));
        if (!d.EndsWith("\\")) d += "\\";
        return d;
    }

    /// Every process whose .exe lives inside the folder (the game, its launcher, crash handlers).
    static List<Process> ProcsIn(string dir)
    {
        List<Process> list = new List<Process>();
        if (string.IsNullOrEmpty(dir)) return list;
        string root = NormDir(dir);
        int self = Process.GetCurrentProcess().Id;
        foreach (Process p in Process.GetProcesses())
        {
            if (p.Id == self || p.Id == 0 || p.Id == 4) continue;
            string path = PathOf(p.Id);
            if (path != null && path.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                list.Add(p);
        }
        return list;
    }

    static int Boost(string dir)
    {
        foreach (Process p in ProcsIn(dir))
        {
            try { p.PriorityClass = ProcessPriorityClass.High; } catch { }
        }
        return 0;
    }

    static int SuspendAll(string dir, bool suspend)
    {
        foreach (Process p in ProcsIn(dir))
        {
            IntPtr h = OpenProcess(SUSPEND_RESUME, false, p.Id);
            if (h == IntPtr.Zero) continue;
            if (suspend) NtSuspendProcess(h); else NtResumeProcess(h);
            CloseHandle(h);
        }
        return 0;
    }

    static int Quit(string dir)
    {
        List<Process> procs = ProcsIn(dir);
        SuspendAll(dir, false);                       // a paused game can't close itself
        foreach (Process p in procs)
        {
            try { p.CloseMainWindow(); } catch { }
        }
        for (int i = 0; i < 16; i++)
        {
            Thread.Sleep(500);
            if (ProcsIn(dir).Count == 0) return 0;
        }
        foreach (Process p in ProcsIn(dir))
        {
            try { p.Kill(); } catch { }
        }
        return 0;
    }

    static void Front(IntPtr hwnd)
    {
        if (hwnd == IntPtr.Zero) return;
        if (IsIconic(hwnd)) ShowWindow(hwnd, 9);       // SW_RESTORE
        uint fg = GetWindowThreadProcessId(GetForegroundWindow(), IntPtr.Zero);
        uint me = GetCurrentThreadId();
        bool attached = fg != me && AttachThreadInput(me, fg, true);
        // A tap of Alt lets a background process take the foreground (Windows' focus lock).
        keybd_event(0x12, 0, 0, UIntPtr.Zero);
        keybd_event(0x12, 0, 2, UIntPtr.Zero);
        SetForegroundWindow(hwnd);
        BringWindowToTop(hwnd);
        if (attached) AttachThreadInput(me, fg, false);
    }

    static int FocusFolder(string dir)
    {
        IntPtr best = IntPtr.Zero;
        long bestMem = 0;
        foreach (Process p in ProcsIn(dir))
        {
            try
            {
                if (p.MainWindowHandle != IntPtr.Zero && p.WorkingSet64 > bestMem)
                {
                    best = p.MainWindowHandle;
                    bestMem = p.WorkingSet64;
                }
            }
            catch { }
        }
        if (best == IntPtr.Zero) return 1;
        Front(best);
        return 0;
    }

    static int FocusPid(int pid)
    {
        Process p = Process.GetProcessById(pid);
        Front(p.MainWindowHandle);
        return 0;
    }

    // ------------------------------------------------------------------ Steam
    static int SteamRoot()
    {
        using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam"))
        {
            object v = k == null ? null : k.GetValue("SteamPath");
            if (v == null) return 1;
            Console.WriteLine(v.ToString().Replace('\\', '/'));
            return 0;
        }
    }

    static int SteamRunning()
    {
        using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam"))
        {
            object v = k == null ? null : k.GetValue("RunningAppID");
            Console.WriteLine(v == null ? "0" : Convert.ToInt64(v).ToString());
            return 0;
        }
    }

    // ------------------------------------------------------------------ capture
    static int Screenshot(string file)
    {
        Rectangle r = SystemInformation.VirtualScreen;
        using (Bitmap bmp = new Bitmap(r.Width, r.Height, PixelFormat.Format32bppArgb))
        {
            using (Graphics g = Graphics.FromImage(bmp))
                g.CopyFromScreen(r.Left, r.Top, 0, 0, r.Size);
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(file)));
            bmp.Save(file, ImageFormat.Png);
        }
        return 0;
    }

    // ------------------------------------------------------------------ info
    static int Drives()
    {
        foreach (DriveInfo d in DriveInfo.GetDrives())
        {
            if (!d.IsReady) continue;
            if (d.DriveType != DriveType.Fixed && d.DriveType != DriveType.Removable) continue;
            Console.WriteLine(string.Format("{0}|{1}|{2}|{3}|{4}",
                d.RootDirectory.FullName.Replace('\\', '/'), d.AvailableFreeSpace, d.TotalSize,
                d.VolumeLabel.Replace("|", " "), d.DriveType == DriveType.Removable ? "usb" : "fixed"));
        }
        return 0;
    }

    static string Wmi(string query, string prop)
    {
        try
        {
            using (ManagementObjectSearcher s = new ManagementObjectSearcher(query))
                foreach (ManagementObject o in s.Get())
                {
                    object v = o[prop];
                    if (v != null) return v.ToString().Trim();
                }
        }
        catch { }
        return "";
    }

    static int About()
    {
        string os = Wmi("SELECT Caption FROM Win32_OperatingSystem", "Caption");
        string build = Wmi("SELECT BuildNumber FROM Win32_OperatingSystem", "BuildNumber");
        Console.WriteLine("os=" + os);
        Console.WriteLine("build=" + build);
        Console.WriteLine("gpu=" + Wmi("SELECT Name FROM Win32_VideoController", "Name"));
        Console.WriteLine("ram=" + Wmi("SELECT TotalPhysicalMemory FROM Win32_ComputerSystem", "TotalPhysicalMemory"));
        return 0;
    }

    // ------------------------------------------------------------------ launching
    /// Starts a game the way double-clicking it would: from its own folder, as you,
    /// so its saves, mods and trainers behave exactly as on the desktop.
    static int Launch(string[] args)
    {
        if (args.Length < 2) return 2;
        string exe = args[1].Replace('/', '\\');
        StringBuilder rest = new StringBuilder();
        for (int i = 2; i < args.Length; i++)
        {
            if (rest.Length > 0) rest.Append(' ');
            rest.Append(args[i].Contains(" ") ? "\"" + args[i] + "\"" : args[i]);
        }
        ProcessStartInfo si = new ProcessStartInfo(exe, rest.ToString());
        si.WorkingDirectory = Path.GetDirectoryName(exe);
        si.UseShellExecute = true;              // .bat/.lnk work, and games that need admin get their prompt
        Process p = Process.Start(si);
        Console.WriteLine(p == null ? "0" : p.Id.ToString());
        return 0;
    }

    // ------------------------------------------------------------------ network
    static string NetshOut(string args)
    {
        ProcessStartInfo si = new ProcessStartInfo("netsh", args);
        si.UseShellExecute = false; si.CreateNoWindow = true; si.RedirectStandardOutput = true;
        using (Process p = Process.Start(si))
        {
            string o = p.StandardOutput.ReadToEnd();
            p.WaitForExit();
            return o;
        }
    }

    static string CurrentSsid()
    {
        Match m = Regex.Match(NetshOut("wlan show interfaces"), @"^\s*SSID\s*:\s*(.+?)\s*$", RegexOptions.Multiline);
        return m.Success ? m.Groups[1].Value : "";
    }

    static int Net()
    {
        bool wired = false, wifi = false;
        string ip = "";
        foreach (NetworkInterface n in NetworkInterface.GetAllNetworkInterfaces())
        {
            if (n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211) wifi = true;
            if (n.OperationalStatus != OperationalStatus.Up) continue;
            IPInterfaceProperties props = n.GetIPProperties();
            if (props.GatewayAddresses.Count == 0) continue;
            if (n.NetworkInterfaceType == NetworkInterfaceType.Ethernet || n.NetworkInterfaceType == NetworkInterfaceType.GigabitEthernet) wired = true;
            foreach (UnicastIPAddressInformation a in props.UnicastAddresses)
                if (a.Address.AddressFamily == AddressFamily.InterNetwork && ip == "") ip = a.Address.ToString();
        }
        Console.WriteLine("wired=" + (wired ? "1" : "0"));
        Console.WriteLine("wifi=" + (wifi ? "1" : "0"));
        Console.WriteLine("ssid=" + (wifi ? CurrentSsid() : ""));
        Console.WriteLine("ip=" + ip);
        return 0;
    }

    static int WifiScan()
    {
        string cur = CurrentSsid();
        string o = NetshOut("wlan show networks mode=bssid");
        string ssid = null, auth = "";
        int signal = 0;
        Dictionary<string, string> seen = new Dictionary<string, string>();
        foreach (string raw in o.Split('\n'))
        {
            string line = raw.Trim();
            Match m = Regex.Match(line, @"^SSID \d+\s*:\s*(.*)$");
            if (m.Success) { ssid = m.Groups[1].Value.Trim(); signal = 0; auth = ""; continue; }
            if (ssid == null || ssid == "") continue;
            m = Regex.Match(line, @"^Authentication\s*:\s*(.*)$");
            if (m.Success) { auth = m.Groups[1].Value.Trim(); continue; }
            m = Regex.Match(line, @"^Signal\s*:\s*(\d+)%");
            if (m.Success)
            {
                signal = Math.Max(signal, int.Parse(m.Groups[1].Value));
                seen[ssid] = string.Format("{0}|{1}|{2}|{3}", ssid.Replace("|", " "), signal,
                    auth.ToLowerInvariant() == "open" ? "0" : "1", ssid == cur ? "1" : "0");
            }
        }
        foreach (string v in seen.Values) Console.WriteLine(v);
        return 0;
    }

    // ------------------------------------------------------------------ console mode safety
    static string DataDir()
    {
        return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FORGE");
    }

    /// Asks the admin "FORGE Console" task to restore everything, and waits for it.
    static void RestoreConsole()
    {
        string dir = DataDir();
        string active = Path.Combine(dir, "console-active");
        if (!File.Exists(active)) return;
        File.WriteAllText(Path.Combine(dir, "console-request.txt"), "exit");
        for (int attempt = 0; attempt < 3 && File.Exists(active); attempt++)
        {
            Run("schtasks", "/run /tn \"FORGE Console\"");
            for (int i = 0; i < 30 && File.Exists(active); i++) Thread.Sleep(500);
        }
    }

    static bool ExplorerRunning()
    {
        return Process.GetProcessesByName("explorer").Length > 0;
    }

    /// Leaves console mode. Runs as you (not admin), so Explorer and OneDrive start normally.
    static int Desktop()
    {
        string state = Path.Combine(DataDir(), "console-state.json");
        bool onedrive = File.Exists(state) && File.ReadAllText(state).Replace(" ", "").Contains("\"onedrive\":true");
        RestoreConsole();
        if (!ExplorerRunning()) Process.Start("explorer.exe");
        if (onedrive)
        {
            string od = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Microsoft\OneDrive\OneDrive.exe");
            if (File.Exists(od)) Process.Start(od, "/background");
        }
        return 0;
    }

    /// Waits for FORGE to close. If it closed while the desktop was hidden (a crash, or it was
    /// ended from Task Manager), the desktop comes back so the PC is never stuck on a black screen.
    static int Watchdog(int pid)
    {
        Process p;
        try { p = Process.GetProcessById(pid); } catch { return 0; }
        p.WaitForExit();
        Thread.Sleep(1500);                     // a clean exit tidies up by itself first
        if (File.Exists(Path.Combine(DataDir(), "console-active")) || !ExplorerRunning())
            return Desktop();
        return 0;
    }

    // ------------------------------------------------------------------ Wi-Fi
    static string Xml(string s)
    {
        return System.Security.SecurityElement.Escape(s);
    }

    static int Run(string exe, string args)
    {
        ProcessStartInfo si = new ProcessStartInfo(exe, args);
        si.UseShellExecute = false;
        si.CreateNoWindow = true;
        si.RedirectStandardOutput = true;
        using (Process p = Process.Start(si))
        {
            p.StandardOutput.ReadToEnd();
            p.WaitForExit();
            return p.ExitCode;
        }
    }

    static int WifiConnect(string ssid, string password)
    {
        if (ssid == "") return 2;
        string security = password == ""
            ? "<authEncryption><authentication>open</authentication><encryption>none</encryption><useOneX>false</useOneX></authEncryption>"
            : "<authEncryption><authentication>WPA2PSK</authentication><encryption>AES</encryption><useOneX>false</useOneX></authEncryption>"
              + "<sharedKey><keyType>passPhrase</keyType><protected>false</protected><keyMaterial>" + Xml(password) + "</keyMaterial></sharedKey>";
        string profile = "<?xml version=\"1.0\"?>"
            + "<WLANProfile xmlns=\"http://www.microsoft.com/networking/WLAN/profile/v1\">"
            + "<name>" + Xml(ssid) + "</name><SSIDConfig><SSID><name>" + Xml(ssid) + "</name></SSID></SSIDConfig>"
            + "<connectionType>ESS</connectionType><connectionMode>auto</connectionMode>"
            + "<MSM><security>" + security + "</security></MSM></WLANProfile>";
        string file = Path.Combine(Path.GetTempPath(), "forge-wifi.xml");
        File.WriteAllText(file, profile, new UTF8Encoding(false));
        try
        {
            Run("netsh", "wlan add profile filename=\"" + file + "\" user=current");
        }
        finally { File.Delete(file); }          // the file holds the password: never leave it behind
        int code = Run("netsh", "wlan connect name=\"" + ssid.Replace("\"", "") + "\"");
        if (code != 0) return 1;
        for (int i = 0; i < 20; i++)
        {
            Thread.Sleep(500);
            ProcessStartInfo si = new ProcessStartInfo("netsh", "wlan show interfaces");
            si.UseShellExecute = false; si.CreateNoWindow = true; si.RedirectStandardOutput = true;
            using (Process p = Process.Start(si))
            {
                string o = p.StandardOutput.ReadToEnd();
                p.WaitForExit();
                if (o.Contains(": connected") && o.Contains(ssid)) return 0;
            }
        }
        return 1;
    }
}

// ---------------------------------------------------------------------- volume (Core Audio)
static class Volume
{
    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    class MMDeviceEnumeratorCom { }

    [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDeviceEnumerator
    {
        [PreserveSig] int EnumAudioEndpoints(int dataFlow, int state, out IntPtr devices);
        [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
    }

    [Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDevice
    {
        [PreserveSig] int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object iface);
    }

    [Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAudioEndpointVolume
    {
        [PreserveSig] int RegisterControlChangeNotify(IntPtr notify);
        [PreserveSig] int UnregisterControlChangeNotify(IntPtr notify);
        [PreserveSig] int GetChannelCount(out int count);
        [PreserveSig] int SetMasterVolumeLevel(float levelDb, ref Guid ctx);
        [PreserveSig] int SetMasterVolumeLevelScalar(float level, ref Guid ctx);
        [PreserveSig] int GetMasterVolumeLevel(out float levelDb);
        [PreserveSig] int GetMasterVolumeLevelScalar(out float level);
        [PreserveSig] int SetChannelVolumeLevel(uint channel, float levelDb, ref Guid ctx);
        [PreserveSig] int SetChannelVolumeLevelScalar(uint channel, float level, ref Guid ctx);
        [PreserveSig] int GetChannelVolumeLevel(uint channel, out float levelDb);
        [PreserveSig] int GetChannelVolumeLevelScalar(uint channel, out float level);
        [PreserveSig] int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid ctx);
        [PreserveSig] int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
    }

    static IAudioEndpointVolume Endpoint()
    {
        IMMDeviceEnumerator en = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom();
        IMMDevice dev;
        Marshal.ThrowExceptionForHR(en.GetDefaultAudioEndpoint(0, 1, out dev));   // render, multimedia
        Guid iid = typeof(IAudioEndpointVolume).GUID;
        object o;
        Marshal.ThrowExceptionForHR(dev.Activate(ref iid, 23, IntPtr.Zero, out o));
        return (IAudioEndpointVolume)o;
    }

    public static int Print()
    {
        IAudioEndpointVolume v = Endpoint();
        float level; bool muted;
        v.GetMasterVolumeLevelScalar(out level);
        v.GetMute(out muted);
        Console.WriteLine(level.ToString("0.000", System.Globalization.CultureInfo.InvariantCulture) + " " + (muted ? "1" : "0"));
        return 0;
    }

    public static int Set(float level)
    {
        Guid g = Guid.Empty;
        Endpoint().SetMasterVolumeLevelScalar(Math.Max(0f, Math.Min(1f, level)), ref g);
        return 0;
    }

    public static int Mute(bool on)
    {
        Guid g = Guid.Empty;
        Endpoint().SetMute(on, ref g);
        return 0;
    }
}
