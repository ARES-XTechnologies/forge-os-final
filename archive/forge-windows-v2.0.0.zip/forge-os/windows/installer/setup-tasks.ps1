# FORGE for Windows — registers (or removes) the "FORGE Console" scheduled task.
# Run by FORGE-Setup.exe (which already has admin rights). You never run this yourself.
#
# The task runs forge-console.ps1 with admin rights:
#   - at sign-in, to undo a console session that was cut short (power loss),
#   - whenever FORGE asks for it (schtasks /run), to enter or leave console mode.
# Because it's a task registered for your account, FORGE can start it without a UAC prompt.

param(
    [string]$App,
    [string]$User,
    [switch]$Remove
)

$ErrorActionPreference = 'Stop'
$Name = 'FORGE Console'

if ($Remove) {
    Unregister-ScheduledTask -TaskName $Name -Confirm:$false -ErrorAction SilentlyContinue
    exit 0
}

$script = Join-Path $App 'forge-console.ps1'
$action = New-ScheduledTaskAction -Execute 'powershell.exe' `
    -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "{0}"' -f $script)
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $User
$principal = New-ScheduledTaskPrincipal -UserId $User -LogonType Interactive -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 5) -MultipleInstances Queue -StartWhenAvailable
Register-ScheduledTask -TaskName $Name -Action $action -Trigger $trigger -Principal $principal `
    -Settings $settings -Description 'FORGE console mode (hides the desktop and pauses background work while you play).' -Force | Out-Null

# Let your normal (non-admin) session start the task, so FORGE never shows a UAC prompt.
$sid = (New-Object System.Security.Principal.NTAccount($User)).Translate([System.Security.Principal.SecurityIdentifier]).Value
$svc = New-Object -ComObject 'Schedule.Service'
$svc.Connect()
$task = $svc.GetFolder('\').GetTask($Name)
$sd = $task.GetSecurityDescriptor(4)          # DACL only, so the new rule lands in the right place
if ($sd -notmatch [regex]::Escape($sid)) {
    $task.SetSecurityDescriptor($sd + "(A;;GRGX;;;$sid)", 0)
}
exit 0
