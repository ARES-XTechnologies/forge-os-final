; FORGE for Windows — installer (Inno Setup 6). Built by the GitHub workflow into FORGE-Setup.exe.
;
; Installs FORGE like a normal app. It changes nothing in Windows by itself: console mode
; (hiding the desktop, pausing background work) only happens while FORGE is open, and is
; undone when you go to the desktop, close FORGE, or uninstall.

#define AppVer "2.0.0"

[Setup]
AppId={{6E2B9C4D-1F7A-4C3B-9E5D-0A8F2B7C1D94}
AppName=FORGE
AppVersion={#AppVer}
AppVerName=FORGE {#AppVer}
AppPublisher=Blacksmith Games
DefaultDirName={autopf}\FORGE
DefaultGroupName=FORGE
DisableProgramGroupPage=yes
OutputDir=..\..\build
OutputBaseFilename=FORGE-Setup
SetupIconFile=forge.ico
UninstallDisplayIcon={app}\FORGE.exe
UninstallDisplayName=FORGE
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
WizardStyle=modern
Compression=lzma2/max
SolidCompression=yes
CloseApplications=force
RestartApplications=no

[Tasks]
Name: "autostart"; Description: "Start FORGE when Windows starts (boots like a console)"; GroupDescription: "Console:"
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"

[Files]
Source: "..\..\build\FORGE.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\build\forge-helper.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\forge-console.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "setup-tasks.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "forge.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\shell\fonts\OFL.txt"; DestDir: "{app}\licenses"; DestName: "Inter-OFL.txt"; Flags: ignoreversion

[Icons]
Name: "{group}\FORGE"; Filename: "{app}\FORGE.exe"; IconFilename: "{app}\forge.ico"
Name: "{group}\FORGE (keep the desktop)"; Filename: "{app}\FORGE.exe"; Parameters: "-- --no-console"; IconFilename: "{app}\forge.ico"
Name: "{group}\Go to desktop (if stuck)"; Filename: "{app}\forge-helper.exe"; Parameters: "desktop"; IconFilename: "{app}\forge.ico"
Name: "{autodesktop}\FORGE"; Filename: "{app}\FORGE.exe"; IconFilename: "{app}\forge.ico"; Tasks: desktopicon

[Registry]
; Start with Windows (as you, not as admin). Can be switched in FORGE › Settings › Console mode.
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "FORGE"; ValueData: """{app}\FORGE.exe"""; Tasks: autostart

[Run]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\setup-tasks.ps1"" -App ""{app}"" -User ""{computername}\{username}"""; Flags: runhidden waituntilterminated; StatusMsg: "Setting up console mode..."
Filename: "{app}\FORGE.exe"; Description: "Start FORGE now"; Flags: nowait postinstall skipifsilent runasoriginaluser

[UninstallRun]
; Close FORGE first: its watchdog (running as you, not admin) puts the desktop and every
; paused service back. Then remove the task and the start-up entry.
Filename: "taskkill.exe"; Parameters: "/f /im FORGE.exe"; Flags: runhidden waituntilterminated; RunOnceId: "CloseForge"
Filename: "powershell.exe"; Parameters: "-NoProfile -Command Start-Sleep -Seconds 10"; Flags: runhidden waituntilterminated; RunOnceId: "WaitRestore"
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\setup-tasks.ps1"" -Remove"; Flags: runhidden waituntilterminated; RunOnceId: "RemoveTask"
Filename: "reg.exe"; Parameters: "delete ""HKCU\Software\Microsoft\Windows\CurrentVersion\Run"" /v FORGE /f"; Flags: runhidden waituntilterminated; RunOnceId: "RemoveAutostart"

[Code]
// Close a running FORGE (and bring the desktop back) before files are replaced on an update.
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  Code: Integer;
begin
  // FORGE's watchdog (running as you) restores the desktop when FORGE closes; give it time.
  if Exec('taskkill.exe', '/f /im FORGE.exe', '', SW_HIDE, ewWaitUntilTerminated, Code) and (Code = 0) then
    Sleep(8000);
  Result := '';
end;
