# FORGE for Windows (v2.0)

The same FORGE console (glass UI, intro, widgets, Library, controller navigation), running on
your normal Windows 11. Games run **natively**: full DirectX 12 speed, anti-cheat games work,
and your saves, mods and trainers are exactly the same as on the desktop (FORGE uses your own
Windows account).

## How it works

- **FORGE opens full screen and hides the Windows desktop** (no taskbar, no Explorer).
- **Performance boost while it's open:** pauses Windows Update, search indexing, telemetry,
  OneDrive, Widgets, Teams and other background apps, switches to the fastest power plan, turns on
  Game Mode, turns off background Game Bar recording, and gives the running game top CPU priority.
- **Go to desktop** (Guide menu › Power, or Settings › Console mode) puts **everything** back
  exactly as it was. Nothing is uninstalled or disabled for good, and Windows Defender and
  security updates are never touched.
- If FORGE ever crashes or is closed, a small watchdog brings the desktop back by itself.

## Step 1: Build FORGE-Setup.exe (once per version, free)

1. Copy everything from this zip into your GitHub folder (replace the old files).
2. In **GitHub Desktop**: write a summary like `FORGE for Windows`, click **Commit**, then **Push origin**.
3. On github.com, open your repository › **Actions** › **Build FORGE for Windows** › **Run workflow**.
4. Wait about 10 minutes for the green tick. Open the run and download **FORGE-Setup** at the
   bottom. Unzip it to get `FORGE-Setup.exe`.

## Step 2: Install

1. Copy `FORGE-Setup.exe` to the console PC and double-click it.
2. Windows may say **"Windows protected your PC"**, because the app isn't code-signed yet.
   Click **More info** › **Run anyway**.
3. Keep **"Start FORGE when Windows starts"** ticked for a console-style start.
4. Finish. FORGE opens.

Your account must be an **administrator** account (most home PCs are). That's what lets
console mode pause Windows services.

## Optional: boot straight into FORGE (no sign-in screen)

1. Settings › Accounts › Sign-in options: turn **off** "For improved security, only allow
   Windows Hello sign-in for Microsoft accounts".
2. Press **Win + R**, type `netplwiz`, press Enter.
3. Untick **"Users must enter a user name and password"**, click OK, type your password twice.

Now the PC goes power button › Windows › FORGE, like a console.

## Controls

| | Controller | Keyboard |
|---|---|---|
| FORGE menu (in a game too) | **View + Menu** together, or Guide | G or Home |
| Switch tabs | LB / RB | Q / E |
| Select / Back | A / B | Enter / Esc |

On Windows, the Guide (Xbox) button often belongs to Steam or the Xbox Game Bar. Use
**View + Menu** for FORGE. To stop Game Bar taking the Guide button: Windows Settings ›
Gaming › Game Bar › turn off "Open Game Bar using this button on a controller".

## Adding games

- **Steam:** everything installed shows up by itself, on every drive.
- **Any other game, trainer or mod launcher:** Library › **+** › pick the `.exe` (or a
  shortcut). It starts from its own folder, exactly like double-clicking it.

## If something goes wrong

- **Black screen, no FORGE:** press **Ctrl + Shift + Esc** (Task Manager) › **Run new task** ›
  type `explorer` › OK. Then use Start › FORGE › **Go to desktop (if stuck)** to restore everything.
- **Want FORGE without hiding the desktop:** Start › FORGE › **FORGE (keep the desktop)**.
- **A game opens behind FORGE:** press **Alt + Tab**.
- **Logs:** `%LOCALAPPDATA%\FORGE\console.log` (console mode) and
  `%APPDATA%\Godot\app_userdata\FORGE OS\` (FORGE itself).

## Uninstall

Settings › Apps › FORGE › Uninstall. Console mode is switched off and everything is restored first.

## Not in this version yet

Clip recording, per-game DLSS/FSR tuning, a built-in FPS overlay (use Steam's overlay or your GPU
app), and FORGE's own Bluetooth pairing screen (it opens Windows' Bluetooth settings instead).
