# FORGE for Windows — console mode (runs with admin rights, no UAC prompt).
#
# Started by the "FORGE Console" scheduled task, which the installer registers with
# "highest privileges" for your account. FORGE (a normal, non-admin app) asks for an
# action by writing it to %LOCALAPPDATA%\FORGE\console-request.txt and running the task:
#
#   enter    hide the desktop and pause everything a console doesn't need
#   exit     put everything back exactly as it was
#   (none)   at sign-in: if the PC lost power while in console mode, put things back
#
# Nothing is uninstalled or disabled for good. Services are only *stopped* (they start
# again by themselves after a restart), and every setting changed is saved first and
# restored on exit. Windows Defender and security services are never touched.

$ErrorActionPreference = 'SilentlyContinue'
$Data    = Join-Path $env:LOCALAPPDATA 'FORGE'
$Request = Join-Path $Data 'console-request.txt'
$State   = Join-Path $Data 'console-state.json'
$Active  = Join-Path $Data 'console-active'
$Prefs   = Join-Path $Data 'console-prefs.json'
$Log     = Join-Path $Data 'console.log'
New-Item -ItemType Directory -Force -Path $Data | Out-Null

function Log([string]$m) {
    Add-Content -Path $Log -Value ("[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m)
}

# Background services a console doesn't need while you play. Stopped only, never disabled.
$Services = @(
    'WSearch',          # search indexing (heavy disk use)
    'SysMain',          # Superfetch / prefetch
    'DiagTrack',        # telemetry
    'dmwappushservice', # telemetry push
    'wuauserv',         # Windows Update (paused while playing, resumes after)
    'UsoSvc',           # update orchestrator
    'DoSvc',            # delivery optimisation (update sharing)
    'MapsBroker',       # offline maps
    'lfsvc',            # location
    'RetailDemo',
    'WerSvc',           # error reporting
    'PcaSvc',           # program compatibility assistant
    'Spooler',          # printing
    'edgeupdate', 'edgeupdatem', 'gupdate', 'gupdatem'   # browser updaters
)

# Background apps closed while in console mode (they start again on the desktop).
$Apps = @('OneDrive', 'Teams', 'ms-teams', 'Widgets', 'WidgetService', 'PhoneExperienceHost',
          'YourPhone', 'GameBar', 'GameBarFTServer', 'Cortana', 'Copilot', 'SkypeApp', 'SkypeBackgroundHost')

$Winlogon = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
$GameCfg  = 'HKCU:\System\GameConfigStore'
$GameDvr  = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'
$GameBar  = 'HKCU:\Software\Microsoft\GameBar'

function Get-Reg($path, $name) {
    $v = Get-ItemProperty -Path $path -Name $name
    if ($v) { return $v.$name } else { return $null }
}
function Set-Reg($path, $name, $value) {
    if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
    if ($null -eq $value) { Remove-ItemProperty -Path $path -Name $name }
    else { Set-ItemProperty -Path $path -Name $name -Value $value -Type DWord }
}

function Get-ActiveScheme {
    $out = powercfg /getactivescheme
    if ($out -match '([0-9a-fA-F-]{36})') { return $Matches[1] }
    return $null
}

function Get-FastScheme {
    # Ultimate Performance if this PC has it (or can add it once), else High performance.
    $list = powercfg /list
    foreach ($line in $list) {
        if ($line -match '([0-9a-fA-F-]{36})\s+\((Ultimate Performance|FORGE Performance)\)') { return $Matches[1] }
    }
    $dup = powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61
    if ($dup -match '([0-9a-fA-F-]{36})') {
        powercfg -changename $Matches[1] 'FORGE Performance' | Out-Null
        return $Matches[1]
    }
    return '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
}

function Enter-Console {
    if (Test-Path $State) {
        if (-not (Get-Process -Name explorer)) { Log 'enter: already in console mode'; return }
        # Left over from a session that never ended (power cut) and the desktop is back:
        # undo it first, then start fresh.
        Log 'enter: undoing an unfinished session first'
        Exit-Console
    }
    $boost = $true
    if (Test-Path $Prefs) {
        $p = Get-Content $Prefs -Raw | ConvertFrom-Json
        if ($null -ne $p.boost) { $boost = [bool]$p.boost }
    }
    $s = @{
        autoRestartShell = Get-Reg $Winlogon 'AutoRestartShell'
        stopped          = @()
        scheme           = $null
        dvr              = Get-Reg $GameCfg 'GameDVR_Enabled'
        capture          = Get-Reg $GameDvr 'AppCaptureEnabled'
        onedrive         = [bool](Get-Process -Name OneDrive)
        boost            = $boost
    }
    # Save first, so a power cut at any point can still be undone.
    $s | ConvertTo-Json | Set-Content -Path $State
    New-Item -ItemType File -Force -Path $Active | Out-Null

    # Desktop off: stop Windows restarting Explorer, then close it. FORGE becomes the screen.
    Set-Reg $Winlogon 'AutoRestartShell' 0
    Stop-Process -Name explorer -Force
    Log 'enter: desktop hidden'

    # Game Mode on (permanent, it's what Windows recommends for games anyway).
    Set-Reg $GameBar 'AutoGameModeEnabled' 1
    Set-Reg $GameBar 'AllowAutoGameMode' 1

    if ($boost) {
        foreach ($name in $Services) {
            $svc = Get-Service -Name $name
            if ($svc -and $svc.Status -eq 'Running') {
                Stop-Service -Name $name -Force -NoWait
                $s.stopped += $name
            }
        }
        foreach ($a in $Apps) { Stop-Process -Name $a -Force }
        # Background screen recording costs FPS; FORGE has its own screenshots.
        Set-Reg $GameCfg 'GameDVR_Enabled' 0
        Set-Reg $GameDvr 'AppCaptureEnabled' 0
        $s.scheme = Get-ActiveScheme
        $fast = Get-FastScheme
        powercfg /setactive $fast | Out-Null
        Log ("enter: paused {0} services, power plan {1}" -f $s.stopped.Count, $fast)
    }
    $s | ConvertTo-Json | Set-Content -Path $State
}

function Exit-Console {
    if (-not (Test-Path $State)) { Remove-Item $Active -Force; return }
    $s = Get-Content $State -Raw | ConvertFrom-Json
    $ars = $s.autoRestartShell
    if ($null -eq $ars) { $ars = 1 }
    Set-Reg $Winlogon 'AutoRestartShell' $ars
    foreach ($name in $s.stopped) { Start-Service -Name $name }
    if ($s.scheme) { powercfg /setactive $s.scheme | Out-Null }
    Set-Reg $GameCfg 'GameDVR_Enabled' $s.dvr
    Set-Reg $GameDvr 'AppCaptureEnabled' $s.capture
    Remove-Item $State -Force
    Remove-Item $Active -Force
    Log ("exit: restored {0} services" -f @($s.stopped).Count)
    # Explorer and OneDrive are restarted by FORGE itself, so they run as you, not as admin.
}

$req = ''
if (Test-Path $Request) {
    $req = (Get-Content $Request -Raw).Trim()
    Remove-Item $Request -Force
}
switch ($req) {
    'enter' { Enter-Console }
    'exit'  { Exit-Console }
    default {
        # Sign-in: undo a console session that never ended (power cut, crash), unless FORGE is open.
        if ((Test-Path $State) -and -not (Get-Process -Name FORGE)) {
            Log 'sign-in: undoing an unfinished console session'
            Exit-Console
        }
    }
}
